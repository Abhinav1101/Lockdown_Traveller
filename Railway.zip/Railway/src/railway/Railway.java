/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package railway;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import static railway.Railway.clientData;

/**
 *
 * @author abhi
 */


class userLogin{
    private String Uname,Pass;
    public static int result;
    userLogin(){
        Uname = Railway.clientData.get(0);
        Pass = Railway.clientData.get(1);
        LoginServerSide lss = new LoginServerSide();
        result = lss.userLogin(Uname,Pass);
//        System.out.println("username = "+Uname+" password = "+Pass);
    }
}

class userSignup{
    private String Name,Email,Uname,Pass,Cpass;
    public static int result;
    userSignup(){
        Name = Railway.clientData.get(0);
        Email = Railway.clientData.get(1);
        Uname = Railway.clientData.get(2);
        Pass = Railway.clientData.get(3);
        Cpass = Railway.clientData.get(4);
        SignupServerSide sss = new SignupServerSide();
        result = sss.userSignup(Name,Email,Uname,Pass,Cpass);
    }
}

class ClientThread extends Thread{
    protected Socket s;
    ClientThread(Socket socket){
        s = socket;
    }
    public void run(){
        try{
            DataInputStream din = new DataInputStream(s.getInputStream());
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());

            String str="";
            String typeOfAction = (String)din.readUTF();
            while(!str.equals("null")){
                str = (String)din.readUTF();
                clientData.add(str);
                System.out.println(str);
            }
            if(typeOfAction.equals("userLogin")){
                userLogin ul = new userLogin();
                str = Integer.toString(ul.result);
                dout.writeUTF(str);
                dout.flush();
                dout.close();
                System.out.println(ul.result);
            }
            else if(typeOfAction.equals("userSignup")){
                userSignup us = new userSignup();
                str = Integer.toString(us.result);
                dout.writeUTF(str);
                dout.flush();
                dout.close();
                System.out.println(userSignup.result);
            }
            din.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}



public class Railway {

    /**
     * @param args the command line arguments
     */
    
    static ArrayList<String> clientData = new ArrayList<String>();
    static java.util.TimerTask task = new java.util.TimerTask() {
        int prevCount = 0; // you can declare it static
        @Override
        public void run() {
            int count=0;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Passenger", "root","");
                String sql = "INSERT INTO ticket SELECT train_no,date_add(CURRENT_DATE,INTERVAL 6 day),720,288,108,36 FROM train";
                PreparedStatement pstInsert = con.prepareStatement(sql);
                pstInsert.executeUpdate();
                String sqlDel = "DELETE FROM ticket where travel_date = CURRENT_DATE ";
                PreparedStatement pstDelete = con.prepareStatement(sqlDel);
                pstDelete.executeUpdate();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    };
    
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        //I HAVE WRITTEN THIS LINE JUST TO MAKE THIS SERVER KEEP RUNNING BUT IF I FIND BETTER METHOD TO KEEP
        // IT RUNNING I WILL COMMENT IT. VISIBITLITY IS 
//        login log = new login();
//        log.setVisible(false);
        
        
        Date prevTiming = null;
        Date timing;
        ServerSocket ss = null;
        Socket s=null;
        try {
            ss = new ServerSocket(6666);
        } catch (IOException ex) {
            Logger.getLogger(Railway.class.getName()).log(Level.SEVERE, null, ex);
        }
        while(true){
            
            try{
                clientData.clear();
                
                s = ss.accept();
//                ss.close();
                Calendar today;
                today = Calendar.getInstance();
                today.set(Calendar.HOUR_OF_DAY, 2);
                today.set(Calendar.MINUTE, 0);
                today.set(Calendar.SECOND, 0);
                System.out.println("time = "+today.getTime());
                
                timing = today.getTime();
                if(timing!=prevTiming){
                    // every night at 2am you run your task
                    prevTiming=timing;
                    Timer timer = new Timer(true);
                    timer.schedule(task, today.getTime(), TimeUnit.MILLISECONDS.convert(1, TimeUnit.DAYS)); // period: 1 day
                }
                
            }
            catch(Exception e){
                e.printStackTrace();
            }
            new ClientThread(s).start();
            
        }
        
        
        
        
        
        
/*      
    java.util.Timer timer = new java.util.Timer(true);// true to run timer as daemon thread
    timer.schedule(task, 0, 86400000);// Run task every 5 second// Run task every 5 second
    try {
        // IMPORTANT
        // MAKE THE INTERRUPTEDEXCEPTION CATCH UNCOMMENT WHEN YOU WILL USE THE SLEEP BELOW
        // INCREASE THE TIME AS YOUR WISH AS LONG AS YOU WANT IT RUN
        Thread.sleep(86400005); // Cancel task after 1 minute.
    } catch (InterruptedException ex) {
        Logger.getLogger(Railway.class.getName()).log(Level.SEVERE, null, ex);
    }
    catch(Exception e){
        e.printStackTrace();
    }
    timer.cancel();
*/
        
        
    }
    
}
